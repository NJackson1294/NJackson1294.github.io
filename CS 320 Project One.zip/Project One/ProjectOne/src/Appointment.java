import java.util.Date;

public class Appointment {
	private final String appointmentID;
	private Date appointmentDate;
	private String description;
	
	
	public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID.");
        }
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must be in the future.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description is invalid.");
        }

        this.appointmentID = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

	// Getters
	public String getAppointmentID() {
		return appointmentID;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getDescription() {
		return description;
	}

	// Setters (Note: No setter for appointmentID as it should not be updatable)
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must be in the future.");
        }
        this.appointmentDate = appointmentDate;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description is invalid.");
        }
        this.description = description;
    }
}
